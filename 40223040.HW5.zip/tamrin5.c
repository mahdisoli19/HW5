#include <stdio.h> //Mahdi Soleimani 40223040
int main()
{
    int n;
    printf("Enter the number: ");
    scanf("%d", &n);
    char a[n + 1];
    printf("Enter the string: ");
    scanf("%s", a);
    int i, j;
    for (i = 0; i < n; i++)
    {
        if (a[i] == a[i + 1])
        {
            for (j = i; j < n - 1; j++)
            {
                a[j] = a[j + 2];
            }
            i = -1;
            printf("Update string: %s\n", a);
        }
    }
    return 0;
}